const createNav = () => {
    let nav = document.querySelector('.navbar');

    nav.innerHTML = `

    <nav class="navbar">
    <div class="nav">
        <img src="img/logo.jpg" class="brand-logo" alt="">
       
        <div class="nav-items">
            <div class="search">
                <input type="text" class="search-box" placeholder="search for a product">
                <button class="search-btn">search</button>
            </div>
            <a class="users" href="login.html"><img src="img/user.png" alt=""></a>
            <a href="cartshop.html"><img src="img/cart.jpg" alt=""></a>
        </div>
    </div>
    </nav>
    <ul class="links-container">
        <li class="link-item"><a href="index.html" class="link">home</a></li>
        <li class="link-item"><a href="products.html" class="link">women</a></li>
        <li class="link-item"><a href="products.html" class="link">men</a></li>
        <li class="link-item"><a href="products.html" class="link">kids</a></li>
        <li class="link-item"><a href="products.html" class="link">accessories</a></li>
    </ul>



    `;
}

createNav();
